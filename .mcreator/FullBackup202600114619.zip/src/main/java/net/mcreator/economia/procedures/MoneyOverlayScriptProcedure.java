package net.mcreator.economia.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.economia.network.EconomiaModVariables;

public class MoneyOverlayScriptProcedure {
	public static String execute(Entity entity) {
		if (entity == null)
			return "";
		if (entity.getData(EconomiaModVariables.PLAYER_VARIABLES).money >= 1000000) {
			return "Money: \u00A7a$" + new java.text.DecimalFormat("##.##").format(entity.getData(EconomiaModVariables.PLAYER_VARIABLES).money / 1000000) + "\u00A7aM";
		} else if (entity.getData(EconomiaModVariables.PLAYER_VARIABLES).money >= 10000) {
			return "Money: \u00A7a$" + new java.text.DecimalFormat("##.##").format(entity.getData(EconomiaModVariables.PLAYER_VARIABLES).money / 1000) + "\u00A7aK";
		} else if (entity.getData(EconomiaModVariables.PLAYER_VARIABLES).money >= 1000) {
			return "Money: \u00A7a$" + new java.text.DecimalFormat("##.##").format(entity.getData(EconomiaModVariables.PLAYER_VARIABLES).money / 1000) + "\u00A7aK";
		} else if (entity.getData(EconomiaModVariables.PLAYER_VARIABLES).money <= 0) {
			return "Money: \u00A7c" + new java.text.DecimalFormat("##.##").format(entity.getData(EconomiaModVariables.PLAYER_VARIABLES).money);
		}
		return "Money: \u00A7a$" + new java.text.DecimalFormat("##.##").format(entity.getData(EconomiaModVariables.PLAYER_VARIABLES).money);
	}
}