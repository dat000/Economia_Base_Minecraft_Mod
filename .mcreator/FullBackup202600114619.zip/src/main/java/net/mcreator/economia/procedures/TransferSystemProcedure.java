package net.mcreator.economia.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.CommandSourceStack;

import net.mcreator.economia.network.EconomiaModVariables;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.DoubleArgumentType;

public class TransferSystemProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, CommandContext<CommandSourceStack> arguments, Entity entity) {
		if (entity == null)
			return;
		if (entity.getData(EconomiaModVariables.PLAYER_VARIABLES).money >= DoubleArgumentType.getDouble(arguments, "moneyWantTransfer")) {
			{
				EconomiaModVariables.PlayerVariables _vars = (commandParameterEntity(arguments, "name")).getData(EconomiaModVariables.PLAYER_VARIABLES);
				_vars.money = (commandParameterEntity(arguments, "name")).getData(EconomiaModVariables.PLAYER_VARIABLES).money + DoubleArgumentType.getDouble(arguments, "moneyWantTransfer");
				_vars.markSyncDirty();
			}
			{
				EconomiaModVariables.PlayerVariables _vars = entity.getData(EconomiaModVariables.PLAYER_VARIABLES);
				_vars.money = entity.getData(EconomiaModVariables.PLAYER_VARIABLES).money - DoubleArgumentType.getDouble(arguments, "moneyWantTransfer");
				_vars.markSyncDirty();
			}
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal(("\u00A7aYou have successfully sent " + "\u00A7e" + new java.text.DecimalFormat("##.##").format(DoubleArgumentType.getDouble(arguments, "moneyWantTransfer")) + "\u00A7a to "
						+ ("\u00A7f" + (commandParameterEntity(arguments, "name")).getDisplayName().getString()))), false);
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("intentionally_empty")), SoundSource.NEUTRAL, 1, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("intentionally_empty")), SoundSource.NEUTRAL, 1, 1, false);
				}
			}
			if ((commandParameterEntity(arguments, "name")) instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal(
						("\u00A7aYou have received " + "\u00A7e" + new java.text.DecimalFormat("##.##").format(DoubleArgumentType.getDouble(arguments, "moneyWantTransfer")) + "\u00A7a from " + ("\u00A7f" + entity.getDisplayName().getString()))),
						false);
		} else {
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("intentionally_empty")), SoundSource.NEUTRAL, 1, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("intentionally_empty")), SoundSource.NEUTRAL, 1, 1, false);
				}
			}
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal(("\u00A7eYou don't have enough money to complete this transfer." + "\u00A7e")), false);
		}
	}

	private static Entity commandParameterEntity(CommandContext<CommandSourceStack> arguments, String parameter) {
		try {
			return EntityArgument.getEntity(arguments, parameter);
		} catch (CommandSyntaxException e) {
			e.printStackTrace();
			return null;
		}
	}
}